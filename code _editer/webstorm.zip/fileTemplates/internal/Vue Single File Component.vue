<template lang="pug">
#[[$END$]]#
</template>

<script>
export default {
  name: "${COMPONENT_NAME}"
}
</script>

<style lang="scss" scoped>
@import '~@/assets/styles/global';

</style>